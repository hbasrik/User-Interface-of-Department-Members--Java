/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package usermain;

/**
 *
 * @author User
 */
public class Staff extends User{
    
    private int monthlyWorkinghour;
    private double hourlywage;
    private double monthlywage;
    private String workType;
    
    public Staff( String name,String surname,int id,int enteranceYear,String password,String workType){
        
        super(name,surname,id,enteranceYear,password);
        this.workType=workType;
        calculateWages();
    
    }
    public void calculateWages(){
        if(enteranceYear < 2015){
            monthlyWorkinghour = 30*5;
            hourlywage = 40;
            monthlywage = hourlywage*30*8;
        }else if(enteranceYear < 2018){
            monthlyWorkinghour = 30*6;
            hourlywage = 35;
            monthlywage = hourlywage*30*8;   
        }
        else{
            monthlyWorkinghour = 30*7;
            hourlywage = 30;
            monthlywage = hourlywage*30*8;    
        }
             
    }

    public int getMonthlyWorkinghour() {
        return monthlyWorkinghour;
    }

    public double getHourlyWage() {
        return hourlywage;
    }

    public double getMonthlyWage() {
        return monthlywage;
    }

    public String getWorkType() {
        return workType;
    }

    public void setMonthlyWorkinghour(int monthlyWorkinghour) {
        this.monthlyWorkinghour = monthlyWorkinghour;
    }

    public void setHourlyWage(double hourlyWage) {
        this.hourlywage = hourlyWage;
    }

    public void setMonthlyWage(double monthlyWage) {
        this.monthlywage = monthlywage;
    }

    public void setWorkType(String workType) {
        this.workType = workType;
    }
    
    public void calculateMonthlyWage(double hourlyWage){
        monthlywage= hourlyWage*720;
    }

    @Override
    public String toString() {
        return "Staff\n" +super.toString()+ "monthlyWorkinghour=" + monthlyWorkinghour + "\nhourlyWage=" + hourlywage + "\nmonthlyWage=" + monthlywage + "\nworkType=" + workType;
    }
    
    
    
    
    
    
    
}
