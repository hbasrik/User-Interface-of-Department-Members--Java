/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package usermain;

/**
 *
 * @author User
 */
public class Course {
    private String name;
    private String code;
    private int credit;
    private int weeklyHour;
    
    public Course(){
    }   
    public String getName() {
        return name;
    }

    public String getCode() {
        return code;
    }

    public int getCredit() {
        return credit;
    }

    public int getWeeklyHour() {
        return weeklyHour;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public void setCredit(int credit) {
        this.credit = credit;
    }

    public void setWeeklyHour(int weeklyHour) {
        this.weeklyHour = weeklyHour;
    }

    @Override
    public String toString() {
        return "Course\n"+ "name=" + name + "\ncode=" + code + "\ncredit=" + credit + "\nweeklyHour=" + weeklyHour;
    }
    
    
    
    
}
