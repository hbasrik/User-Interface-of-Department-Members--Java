/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package usermain;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author User
 */
public class UserSys {
    private static final String FILE_NAME = "yıkıklar.txt";
    private static ArrayList<User> arr = new ArrayList();

    public static boolean checkId(int id) {
        for (int i = 0; i < arr.size(); i++) {
            User b = arr.get(i);
            if (b.checkId(id)) {
                return true;
            }
        }
        return false;
    }
    public static void readFromFile(){
        File file = new File(FILE_NAME);
        if(!file.exists()){
            
        }
        else{
            try {
                Scanner input = new Scanner((file));
                while(input.hasNext()){
                    
                }
            } catch (FileNotFoundException ex) {
                Logger.getLogger(UserSys.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        }
        
    }
    public static void writeToFile(){
        File file = new File(FILE_NAME);
        try{
            FileWriter fw = new FileWriter(FILE_NAME, false);
            PrintWriter pw = new PrintWriter(fw, false);
            pw.flush();
         }catch(Exception exception){
             System.out.println("Exception have been caught");
        }
        for(int i = 0;i< arr.size();i++){
            if(arr.get(i) instanceof Student){
                //Student Name Surname ID Password EntranceYear 
            }
            else if(arr.get(i) instanceof Staff){
                 //Staff Name Surname ID Password EntranceYear WorkType
            }
            else{
                  //Instructor Name Surname ID Password EntranceYear InterestedArea
                
            }
        }
                
    }
    public static boolean addUser(User user) {
        if(!checkId(user.getId())){
            arr.add(user);
            return true;
        }else{
            return false;
        }
    }
    
     public static boolean removeUser(int id) {
        for (int i = 0; i < arr.size(); i++) {
            int uid = arr.get(i).getId();
            if (uid == id) {
                arr.remove(i);
                return true;
            }
        }
        return false;
    }
     public static User getUser(int id){
         if(checkId(id)){
             for(int i = 0;i< arr.size();i++){
                 if(id == arr.get(i).getId())
                     return arr.get(i);
             }
         }
         return null;
     }
     
     public static String display() {
        User temp;
        String out = "";
        for (int i = 0; i < arr.size(); i++) {

            temp = (User) arr.get(i);
            out += temp.toString() + "\n\n";
        }
        return out;
    }
     public static ArrayList<User> getUsers() {
        return arr;
    }   
}

