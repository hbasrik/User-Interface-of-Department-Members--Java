/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package usermain;

import java.util.ArrayList;

/**
 *
 * @author User
 */
public class Instructor extends User {
    private double monthlyWage;
    private String interestedArea;
    private int monthlyWorkingHours;
    private double hourlyWage;
    private String out;
    private ArrayList<Student> students = new ArrayList();
    private ArrayList<Course> coursesGiven = new ArrayList();
 
    public Instructor(String name,String surname,int id,int enteranceYear ,String password,String interestedArea){
        super(name,surname,id,enteranceYear,password);
        this.interestedArea=interestedArea;
        calculateWages();
    }   
    
    public boolean addCourse(Course course){
        if(getCourse(course.getCode())== null){
            coursesGiven.add(course);
            return true;
        }
        return false;       
    }
    public Course getCourse(String courseCode){
        for(int i = 0;i<coursesGiven.size();i++){
            if(coursesGiven.get(i).getCode().equalsIgnoreCase(courseCode))
                return coursesGiven.get(i);
        }
        return null;
    }
    public void fillStudentsBasedOnCourses(){
        out ="";
        ArrayList<User> allUsers= UserSys.getUsers();
        
        for(User user: allUsers){
            if(user instanceof Student){
                Boolean exists= false;
                while(!exists){
                    for(Course course:((Student) user).getCoursesTaken()){
                        if(getCourse(course.getCode())!= null){
                            exists = true;
                            out += ((Student)user).toString()+"\n";
                            students.add((Student) user);
                            break;
                        }
                    }
                }
            }
        }
    }
    public String displayStudents(){
        return out;
    }
    
    public void calculateWages(){
        if(enteranceYear < 2015){
            monthlyWorkingHours= 30*6;
            hourlyWage = 60;
            monthlyWage = hourlyWage*30*8;
        }else if(enteranceYear < 2018){
            monthlyWorkingHours= 30*7;
            hourlyWage = 50;
            monthlyWage = hourlyWage*30*8;  
        }
        else{
            monthlyWorkingHours= 30*8;
            hourlyWage = 40;
            monthlyWage = hourlyWage*30*8;   
        }
             
    }
             
    
    
    public Student checkStudent(int id){
        for(int i = 0;i<students.size();i++){
            if(students.get(i).checkId(id))
                return students.get(i);
        }
        return null;
    }
    public boolean addStudent(Student student){
        if(checkStudent(student.getId())!= null){
           students.add(student);
           return true;}
        else
            return false;      
    }
    
    public boolean setStudentGrade(int id,double grade){
         if(checkStudent(id)!= null){
           return true;}
        else
            return false;      
    }
  
    public double getMonthlyWage() {
        return monthlyWage;
    }

    public String getInterestedArea() {
        return interestedArea;
    }

    public void calculateMonhtly(double hourlyWage){
        monthlyWage= 720*hourlyWage;
    }

    public double getHourlyWage() {
        return hourlyWage;
    }

    public void setMonthlyWage(double monthlyWage) {
        this.monthlyWage = monthlyWage;
    }

    public void setInterestedArea(String interestedArea) {
        this.interestedArea = interestedArea;
    }

    public void setMonhlyWorkingHours(int monhlyWorkingHours) {
        this.monthlyWorkingHours = monthlyWorkingHours;
    }

    public void setHourlyWage(double hourlyWage) {
        this.hourlyWage = hourlyWage;
    }

    @Override
    public String toString() {
        return "Instructor\n"+ super.toString()+ "monthlyWage=" + monthlyWage + "\ninterestedArea=" + interestedArea + "\nmonhlyWorkingHours=" + monthlyWorkingHours + "\nhourlyWage=" + hourlyWage ;
    }


   

    








}
