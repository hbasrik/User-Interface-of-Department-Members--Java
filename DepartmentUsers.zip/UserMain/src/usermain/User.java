/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package usermain;

/**
 *
 * @author User
 */
public class User {
    protected String name;
    protected String surname;
    protected int id;
    protected int enteranceYear;
    protected String password;
    
    public User(String name, String surname, int id, int enteranceYear, String password){
      
        this.name=name;
        this.surname=surname;
        this.id=id;
        this.enteranceYear=enteranceYear;
        this.password=password;   
    }

    public String getName() {
        return name;
    }

    public String getSurname() {
        return surname;
    }

    public int getId() {
        return id;
    }

    public int getEnteranceYear() {
        return enteranceYear;
    }

    public String getPassword() {
        return password;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setEnteranceYear(int enteranceYear) {
        this.enteranceYear = enteranceYear;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    public boolean checkId(int id){
        return this.id==id;
    }
    
     public boolean checkPassword(String password){
        return this.password.equals(password);
    }
  

    @Override
    public String toString() {
        return "User\n" + "name=" + name + "\nsurname=" + surname + ", id=" + id + "\nenteranceYear=" + enteranceYear + "\npassword=" + password ;
    }
      
    
    
}
