/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package usermain;

import java.util.ArrayList;

/**
 *
 * @author User
 */
public class Student extends User{
    
    private double cgpa;
    private int attendance;
    private ArrayList<Course> coursesTaken = new ArrayList<>();
    
    public Student(String name, String surname, int id, int enteranceYear, String password){
       super(name,surname,id,enteranceYear,password);
       this.attendance=attendance;
       this.cgpa=cgpa;
    }

    public double getCgpa() {
        return cgpa;
    }
    public boolean addCourse(Course course){
        if(!checkCourse(course.getCode())){
            coursesTaken.add(course);
            return true;
        }
        return false;
    }
    public boolean checkCourse(String code){
        for(int i= 0;i< coursesTaken.size();i++){
            if(coursesTaken.get(i).getCode().equalsIgnoreCase(code))
                return true;
        }
        return false;
    }
    public int getAttendance() {
        return attendance;
    }

    public ArrayList<Course> getCoursesTaken() {
        return coursesTaken;
    }

    public void setCgpa(double cgpa) {
        this.cgpa = cgpa;
    }

    public void setAttendance(int attendance) {
        this.attendance = attendance;
    } 
    
     @Override
    public String toString() {
        String opStr = "";
        for (Course o : coursesTaken) {
            opStr += o.toString() + "\n";
        }
        return "\nStudent" + super.toString();    
    }
    
}
